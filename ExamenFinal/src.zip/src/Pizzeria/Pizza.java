package Pizzeria;

public interface Pizza {
    String getNombre();
    String getDescripcion();
    double getPrecio();
}
